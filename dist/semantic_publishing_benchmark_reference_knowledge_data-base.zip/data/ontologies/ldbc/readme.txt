ldbc-conformance.0.3.zip should not be unzippped, all contents are broken down to separate files in folders : 
    ../../sparql/base/conformance/ontology-breakdown
    ../../sparql/full/conformance/ontology-breakdown