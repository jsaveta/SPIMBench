#!/bin/bash
echo "Starting system_start procedure..."

#TODO : add system specific commands here
touch system_start.txt
sleep 3s
