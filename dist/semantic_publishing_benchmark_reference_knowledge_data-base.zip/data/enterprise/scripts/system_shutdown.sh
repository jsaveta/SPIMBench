#!/bin/bash
echo "Starting system_shutdown procedure..."

#TODO : add system specific commands here
touch system_shutdown.txt
sleep 3s
