#!/bin/bash
echo "Starting full_backup_start procedure..."

#TODO : add system specific commands here
touch incremental_backup_start.txt
sleep 3s
