#!/bin/bash
echo "Starting full_backup_restore procedure..."

#TODO : add system specific commands here
touch full_backup_restore.txt
sleep 3s
